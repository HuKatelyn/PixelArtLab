import java.awt.Graphics;
import java.awt.Color;

public class Square{
    private Color squareColor;

    public Square(){
        squareColor = new Color(255, 255, 255);
    }

    public void drawMe(Graphics g, int x, int y){
        g.setColor(squareColor);
        g.fillRect(x, y, 35, 35);
        g.setColor(Color.BLACK);
        g.drawRect(x, y, 35, 35);
    }

    public void setColor(Color selectedColor){
        //set the instance varaibles for the red, green, and blue, to what is passed in
        squareColor = selectedColor;
    }
}