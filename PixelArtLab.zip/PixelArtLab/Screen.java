import javax.swing.JPanel;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;


public class Screen extends JPanel implements MouseListener, ActionListener{
	
    private Square[][] grid;
    private Square[][] palette;
    private Color[] color;
    private JButton reset;
    private String notificationText;
    private Color selectedColor;
    private int gridX;
    private int gridY;
    private int squareSize;
    private int sideLength;
    private int paletteX;
    private int paletteY;
    private int colorSize;
    private int colorLength;
    private int colorWidth;
    private int colorIndex;
	
    public Screen(){
        setLayout(null);

        gridX = 0;
        gridY = 0;
        squareSize = 35;
        sideLength = 560;

        paletteX = 600;
        paletteY = 0;
        colorSize = 35;
        colorLength = 420;
        colorWidth = 105;
        colorIndex = 0;

        notificationText = " ";
        addMouseListener(this);
        //fill array color with colors
        color = new Color[36];
        color[0] = new Color(0,0,0); //black
        color[1] = new Color(128,128,128); //grey
        color[2] = new Color(255,255,255); //white
        color[3] = new Color(59, 29, 2); //dark brown
        color[4] = new Color(92, 46, 1); //brown
        color[5] = new Color(128, 74, 22); //light brown
        color[6] = new Color(135, 3, 3); //dark red
        color[7] = new Color (255, 5, 5); //red
        color[8] = new Color(250, 115, 115); //light red
        color[9] = new Color(181, 85, 2); //dark orange
        color[10] = new Color(252, 118, 3); //orange
        color[11] = new Color(250, 172, 105); //light orange
        color[12] = new Color(196, 171, 4); //dark yellow
        color[13] = new Color(255, 222, 5); //yellow
        color[14] = new Color(245, 226, 100); //light yellow
        color[15] = new Color(61, 194, 4); //dark yellow green
        color[16] = new Color(78, 252, 3); //yellow green
        color[17] = new Color(145, 250, 100); //light yellow green
        color[18] = new Color(1, 46, 5); //dark green
        color[19] = new Color(3, 84, 10); //green
        color[20] = new Color(28, 120, 36); //light green
        color[21] = new Color(3, 68, 130); //dark blue
        color[22] = new Color(3, 130, 252); //blue
        color[23] = new Color(100, 176, 250); //light blue
        color[24] = new Color(5, 3, 145); //dark indigo
        color[25] = new Color(6, 3, 252); //indigo
        color[26] = new Color(90, 88, 245); //light indigo
        color[27] = new Color(68, 3, 171); //dark purple
        color[28] = new Color(100, 3, 255); //purple
        color[29] = new Color(144, 79, 247); //light purple
        color[30] = new Color(110, 3, 156); //dark magenta
        color[31] = new Color(179, 3, 255); //magenta
        color[32] = new Color(200, 92, 247); //light magenta
        color[33] = new Color(163, 2, 136); //dark pink
        color[34] = new Color(252, 3, 211); //pink
        color[35] = new Color(247, 116, 226); //light pink
        

        grid = new Square[16][16];
        for(int r = 0; r < grid.length; r++){
            for(int c = 0; c < grid[r].length; c++){
                grid[r][c] = new Square();
            }
        }

        palette = new Square[12][3];
        for(int r = 0; r < palette.length; r++){
            for(int c = 0; c < palette[r].length; c++){
                palette[r][c] = new Square();
            }
        }

        //reset button
        reset = new JButton("Clear");
        reset.setBounds(600,450, 100, 30); //sets the location and size
        reset.addActionListener(this); //add the listener
        this.add(reset); //add to JPanel
    }

	public Dimension getPreferredSize(){
		return new Dimension(800,600);
		
	}
	
	public void paintComponent(Graphics g){
		super.paintComponent(g);
        
        //draw grid
        int x = 0;
        int y = 0;
        for(int r = 0; r < grid.length; r++){
            for(int c = 0; c < grid[r].length; c++){
                grid[r][c].drawMe(g, x, y);
                x += 35;
            }
            x = 0;
            y += 35;
        }


        
        //draw color palette
        int x2 = 600;
        int y2 = 0;
        int i = 0;

        for(int r = 0; r < palette.length; r++){
            for(int c = 0; c < palette[r].length; c++){
                palette[r][c].setColor(color[i]);
                palette[r][c].drawMe(g, x2, y2);
                x2 += 35;
                i++;
            }
            x2 = 600;
            y2 += 35;
        }

	}

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == reset) {
            for(int r = 0; r < grid.length; r++){
                for(int c = 0; c < grid[r].length; c++){
                    grid[r][c].setColor(color[2]);
                }
            }
            repaint();
        }
    }
	
    public void mousePressed(MouseEvent e){
        //if user presses a area of a color, set rgb to the values of that color
        paletteY = 0;
        paletteX = 600;
        colorIndex = 0;
        for(int r = 0; r<palette.length; r++){
            for(int c = 0; c<palette[r].length; c++){
                if (e.getX() >= paletteX && e.getX() < paletteX+colorSize && e.getY() >= paletteY && e.getY() < paletteY+colorSize) {
                    selectedColor = color[colorIndex];
                }
                colorIndex += 1;
                paletteX += 35;
            }
            paletteX = 600;
            paletteY +=35;
        }

        // Top left: 0,0, Bottom Right: 267, 200
        if (e.getX() >= gridX && e.getX() < gridX+sideLength && e.getY() >= gridY && e.getY() < gridY+sideLength) {
            grid[(e.getY()-gridY)/squareSize][(e.getX()-gridX)/squareSize].setColor(selectedColor);
        }
        repaint();
    }

    public void mouseReleased(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
    public void mouseClicked(MouseEvent e) {}
}